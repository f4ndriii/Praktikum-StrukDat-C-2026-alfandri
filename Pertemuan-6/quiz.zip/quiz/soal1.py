produk = {}



def registrasi_gadget(merk, tipe, harga, sn):
    if harga >= 1000000 and len(sn) >= 5:
        dict = {
            "merk" : merk,
            "tipe" : tipe,
            "harga" : harga,
            "sn" : sn,
            "status" : "Tersedia"
        }
        return dict
    else:
        print("Input tidak valid...")
        return None

for i in range(3):
    merk = input("Masukkan merk: ")
    tipe = input("Masukkan tipe: ")
    harga = float(input("Masukkan harga: "))
    sn = input("Masukkan sn: ")

    produk.update(registrasi_gadget(merk, tipe, harga, sn))

for x in produk:
    print(x)